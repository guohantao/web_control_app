from django.contrib import admin

# Register your models here.
from default.models import Machine



admin.site.register(Machine)
